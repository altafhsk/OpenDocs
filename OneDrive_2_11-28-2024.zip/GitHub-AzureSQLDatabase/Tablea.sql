CREATE TABLE [dbo].[Tablea] (
    [col1] INT NOT NULL,
    [colc] VARCHAR (10) NULL
)



GO



GO

